package com.aswini.cart.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception {

	public NoProperDataException(String message) {
		super(message);

	}

	
}
