package com.aswini.cart.service;

import java.util.List;

import com.aswini.cart.entity.Cart;
import com.aswini.cart.exception.CartNotFoundException;
import com.aswini.cart.exception.NoProperDataException;





public interface CartService {
	public List<Cart> getAllCustomers();
	public Cart getCartById(int id ) throws CartNotFoundException;
	public Cart addCart( Cart product) throws NoProperDataException;
	public String deleteCart(int id) throws CartNotFoundException;
	

}
