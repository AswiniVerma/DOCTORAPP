package com.aswini.order.service;
import java.util.List;

import com.aswini.order.entity.Order;
import com.aswini.order.exception.NoProperDataException;
import com.aswini.order.exception.OrderNotFoundException;


public interface OrderService {
	public  List<Order> getAllOrders() throws  OrderNotFoundException;
	public Order getOrderById( int id) throws OrderNotFoundException;
	public Order addOrders( Order order)  throws NoProperDataException;
	public String deleteOrder( int id) throws OrderNotFoundException;
}
