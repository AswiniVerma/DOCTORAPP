package com.aswini.order.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.aswini.order.entity.Order;



@Repository
public interface OrderRepository extends MongoRepository<Order, Integer> {

}
