package com.aswini.product;

import org.junit.jupiter.api.Test;


import org.springframework.boot.test.context.SpringBootTest;





@SpringBootTest(classes = ProductServiceApplicationTests.class)
class ProductServiceApplicationTests {
	
	@Test
	void contextLoads() {
	}

}
