package com.aswini.product.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception {

	public NoProperDataException(String message) {
		super(message);

	}

	
}
