package com.aswini.authentication.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception {
	
	public NoProperDataException(String ss)
	{
		super(ss);
	}

}
